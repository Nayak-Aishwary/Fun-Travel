package com.driver.funtravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuntravelcompanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
