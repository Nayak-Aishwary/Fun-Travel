package com.driver.funtravel.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.driver.funtravel.model.DriverDetails;
import com.driver.funtravel.repository.DriverRepository;

@Controller
public class DriverController {

	@Autowired
	DriverRepository driverRepo;

	@GetMapping("/driverdetails")
	public ModelAndView driverDetails(Pageable pageable) {
		ModelAndView model = new ModelAndView();
		System.out.println("Hi");
		Page<DriverDetails> pages = driverRepo.findAll(pageable);
		model.addObject("number", pages.getNumber());
		model.addObject("totalPages", pages.getTotalPages());
		model.addObject("totalElements", pages.getTotalElements());
		model.addObject("size", pages.getSize());
		model.addObject("driverDetails", pages.getContent());
		System.out.println(pages.getSize());
		model.setViewName("DriverDetails");
		return model;
	}

	@PostMapping("/addDriver")
	public ModelAndView addDriver(DriverDetails driver) {
		ModelAndView mv = new ModelAndView();
		driverRepo.save(driver);
		mv.addObject("driver", driver);
		mv.setViewName("RegisterSuccess");
		return mv;
	}

	@PostMapping("updateDriver/updateDriverDetails")
	public ModelAndView addUpdatedDriver(DriverDetails  driver) {
		ModelAndView mv = new ModelAndView();
		driverRepo.save(driver);
		mv.addObject("driver", driver);
		mv.addObject("driverUpdated", "Driver Profile Updated!");
		mv.setViewName("RegisterSuccess");
		return mv;
	}

	@GetMapping("/updateDriver/{driverId}")
	public ModelAndView updateDriver(@PathVariable int driverId) {
		ModelAndView model = new ModelAndView();
		Optional<DriverDetails> driverdetails = driverRepo.findById(driverId);
		if (driverdetails.isPresent()) {
			DriverDetails driver = driverdetails.get();
			driverRepo.save(driver);
			model.addObject("driver", driver);
			model.setViewName("UpdateDriver");
			return model;
		} else {
			model.setViewName("DriverDetails");
		}
		return model;
	}

	@GetMapping("/deleteDriver/{driverId}")
	public ModelAndView deleteDriver(@PathVariable int driverId) {
		Optional<DriverDetails> driverdetails = driverRepo.findById(driverId);
		ModelAndView model = new ModelAndView();
		if (driverdetails.isPresent()) {
			DriverDetails driver = driverdetails.get();
			model.addObject("driver", driver);
			model.setViewName("RegisterSuccess");
			driverRepo.deleteById(driverId);
			model.addObject("deleteMessage", "Driver profile Deleted");
			return model;
		}
		model.setViewName("DriverDetails");
		return model;
	}
}
